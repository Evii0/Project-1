<?php
class Pages extends CI_Controller {

    public function view($page = 'QualificationSelection')
    {
        if ( ! file_exists(APPPATH.'views/pages/Training Agreement/'.$page.'.php'))
        {
                // Whoops, we don't have a page for that!
                show_404();
        }

        $data['title'] = ucfirst($page); // Capitalize the first letter

        $this->load->view('templates/header', $data);
        $this->load->view('templates/navigation', $data);
        $this->load->view('pages/Training Agreement/QualificationSelection', $data);
        $this->load->view('pages/Training Agreement/QualificationRecognition', $data);
        $this->load->view('templates/footer', $data);
    }

}
