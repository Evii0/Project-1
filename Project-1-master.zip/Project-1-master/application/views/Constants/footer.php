        <div id="footer" style="width: 100%;
    height: 80px;
    padding-top: 12px;
    bottom: 0;
    position: absolute;
    text-align: center;
    background-color: #e7e7e7;
    color: black;
    font-size: 0.9em;">
            <p>&copy;2016 Skills Ltd.</p>
            <p>Built By IWS Design Ltd.</p>
        </div>        

        <script src="vendor/jquery/jquery.min.js"></script>

        <!-- Bootstrap Core JavaScript -->
        <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

        <!-- Metis Menu Plugin JavaScript -->
        <script src="vendor/metisMenu/metisMenu.min.js"></script>

        <!-- Morris Charts JavaScript -->
        <script src="vendor/raphael/raphael.min.js"></script>
        <script src="vendor/morrisjs/morris.min.js"></script>
        <script src="dist/js/morris-data.js"></script>

        <!-- Custom Theme JavaScript -->
        <script src="dist/js/sb-admin-2.js"></script>

        <!-- Validation Javascript -->
        <script src="application/views/Constants/Javascript/Validation.js"></script>

    </body>
</html>